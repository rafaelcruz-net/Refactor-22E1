describe('Turn Ticket Dispenser', function () {

	describe('TurnTicketDispenser', function () {

		it('Do something', function () {

			var target = new TicketDispenser();

		});

	});

});
