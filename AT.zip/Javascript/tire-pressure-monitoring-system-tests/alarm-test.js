describe('Tyre Pressure Monitoring System', function () {

	describe('Alarm', function () {

		it('Do something', function () {

			var target = new Alarm();
			target.check();
			
		});

	});

});
