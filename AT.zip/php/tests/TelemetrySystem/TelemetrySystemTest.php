<?php

declare(strict_types=1);

namespace Tests\TelemetrySystem;

use PHPUnit\Framework\TestCase;

class TelemetrySystemTest extends TestCase
{
    public function test_CheckTransmission_ShouldSendAndReceiveDiagnosticMessage() {
        $this->markTestIncomplete();
    }

}